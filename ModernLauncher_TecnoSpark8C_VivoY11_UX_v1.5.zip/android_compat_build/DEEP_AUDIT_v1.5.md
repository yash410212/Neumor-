# Modern Launcher UX v1.5 — Deep Audit

## Fixed
- Missing Gradle wrapper bootstrap: `gradlew`/`gradlew.bat` no longer require a missing `gradle-wrapper.jar`; they bootstrap Gradle 8.13 when network is available.
- Compile error: duplicate `AnimationType.FADE` branch removed.
- Compile error: drag-grid `value` was referenced before declaration; order fixed.
- Compile error: Settings reset callback passed the wrong function signature; now supplies `Context`.
- Icon scale preferences are loaded on startup.
- Animation value/duration are clamped on persistence and restore.
- Widget records are normalized so the same provider cannot occupy multiple pages.
- Duplicate widget allocation IDs are deleted when a duplicate provider is selected.
- Page indices are clamped and pager state is corrected if page count changes.
- Neumorphic surfaces now use layered light, highlight, shadow and edge passes in both light and dark themes.

## Widget policy
One widget provider = one home-page placement. Removing and reinstalling the launcher does not create one visual copy per page. Existing duplicate records are collapsed to the first page and orphaned host IDs are cleaned up on startup.

## Verification limitation
This environment does not contain an Android SDK, Gradle installation, or the original Gradle wrapper JAR, and outbound DNS/network access is unavailable. Therefore a local Android compile/install test could not be executed here. The project has been statically audited and the build bootstrap has been repaired for GitHub/online environments.
