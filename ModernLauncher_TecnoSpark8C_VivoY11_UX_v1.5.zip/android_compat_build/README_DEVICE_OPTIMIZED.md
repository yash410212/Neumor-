# Modern Launcher — UX v1.2 performance + animation pass

Base: Tecno Spark 8C / KG5K and vivo Y11 compatible Android launcher.

## UX / animation
- Open/close transitions added for Settings, App Drawer and Folder overlays.
- App launch uses a native fade transition where supported.
- Drag/drop uses tuned spring/tween settling instead of a rough movement profile.
- Animation Value is now used as motion-strength input rather than being a display-only slider.
- Animation Type and Duration both affect motion behavior.
- Stronger default animation profile: 85% value, 320 ms duration, Spring type.
- Touch Response default is 180 Hz to match the device's touch sampling capability.
- Battery Saver applies a controlled reduction to launcher animation workload while preserving the user's saved animation settings.

## Performance modes
- **High Performance:** full visual/animation profile with one adjacent page composed.
- **Lite Performance:** lower background/page composition and icon bitmap memory.
- **Extreme Performance:** maximum launcher-side responsiveness, larger icon cache, more adjacent pager composition and a preferred display mode up to the device's supported 90 Hz refresh rate. It does not exceed hardware/OS limits.

## Battery Saver
This is a launcher-only power-saving mode. It reduces launcher animation workload and other unnecessary visual work; it does **not** enable Android's system Battery Saver.

The UI reports:
- time since launcher saver was enabled;
- battery percentage used since activation, when available;
- an explicit note that exact battery *saved* cannot be measured by the launcher without a counterfactual baseline. Android system battery usage is the authoritative measurement.

## Device input/output profile
- Display refresh: **90 Hz** target/limit on the user's device.
- Touch sampling/response: **180 Hz** target.
- The launcher targets 90 Hz rendering and low-latency 180 Hz touch handling; it does not claim to render at 180 FPS.

## Build
The archive includes the Gradle project. Build with Android Studio or GitHub Actions with Android SDK/Gradle dependencies available.
