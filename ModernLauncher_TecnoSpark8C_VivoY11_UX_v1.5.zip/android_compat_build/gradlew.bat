@echo off
setlocal
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.13"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_HOME=%GRADLE_USER_HOME%\launcher-bootstrap\gradle-%GRADLE_VERSION%"
if exist "%GRADLE_HOME%\bin\gradle.bat" goto RUN
where gradle >nul 2>&1
if %ERRORLEVEL% EQU 0 goto SYSTEM
set "CACHE=%GRADLE_USER_HOME%\launcher-bootstrap"
if not exist "%CACHE%" mkdir "%CACHE%"
set "ARCHIVE=%CACHE%\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%ARCHIVE%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ARCHIVE%'"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ARCHIVE%' '%CACHE%\extract'"
for /d %%D in ("%CACHE%\extract\gradle-%GRADLE_VERSION%*") do set "FOUND=%%~fD"
if not defined FOUND exit /b 1
if exist "%GRADLE_HOME%" rmdir /s /q "%GRADLE_HOME%"
move "%FOUND%" "%GRADLE_HOME%" >nul
:RUN
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
:SYSTEM
gradle %*
exit /b %ERRORLEVEL%
